###     Hyperion version 3.0 
###     Installation Tutorial Linux UBuntu 20.04  for Debian use ,Hyperionv3 kali version 
####  > Installation step [1]
![Install_Hypv3](https://user-images.githubusercontent.com/59021489/106630708-5fa60d00-657c-11eb-9acd-0ecfd23ba6bb.gif)

```python
Linux Platform Installation Guide , Installations Hyperionv3:
       Ubuntu , Mint currently ** not compatible with kali linux Debian ** take the version for *Debian and kali linux* : 
       *HyperionV3-kali-linux* on my github
       apt-get udpate && upgrade
      
      
       git clone https://github.com/F0rbidden-Equation/HyperionV3.git
       cd HyperionV3
       cd install
       sudo chmod +x Install_Hyperionv3.py
       sudo chmod +x auto_install.sh
       sh auto_install.sh
       
 ```
 ####  > Installation step [2]
 ![Ubuntu_gui](https://user-images.githubusercontent.com/59021489/106791558-5d63b180-6655-11eb-84f6-d802711ace0d.gif)
 ##### !! Warning, do not close the process bar after starting the installation !!
 
 ###     Installation Tutorial Linux Mint 20
 #### > Install step [1]
 ![Mint_Instal](https://user-images.githubusercontent.com/59021489/106781142-05bf4900-6649-11eb-8c9f-10d63b20966a.gif)
 ```python
Linux Platform Installation Guide , Installations Hyperionv3:
     Ubuntu , Mint currently ** not compatible with kali linux Debian **
       apt-get udpate && upgrade
      
       git clone https://github.com/F0rbidden-Equation/HyperionV3.git
       cd HyperionV3
       cd install
       sudo chmod +x Install_Hyperionv3.py
       sudo chmod +x auto_install.sh
       sh auto_install.sh
 ```
#### > Install step [2]
 ![gui_installMint](https://user-images.githubusercontent.com/59021489/106792109-0dd1b580-6656-11eb-852f-634a2552fb2a.gif)
##### !! Warning, do not close the process bar after starting the installation !!
#### > Starting  Hyperionv3 program step [3]
```python
step [2] Starting Hyperionv3 for Mint,Ubuntu :
cd HyperionV3
sudo chmod +x HyperionV3.py
python3 HyperionV3.py
 ```

