#!/bin/sh


sudo apt-get install git  python3 python3-pip nmap nikto wkhtmltopdf python3-tk xsltproc python3-pyqt5

sudo apt-get install -y python3-pyqt5.qtwebkit.
pip3 install python3-nmap
python3 Install_Hyperionv3.py
