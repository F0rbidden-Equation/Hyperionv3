pip3 install --user --upgrade PyQt5
pip3 install --user --upgrade PyQtWebEngine
sudo apt-get install libxcb-render-util0 libxcb-image0 libxcb-keysyms1 libxcb-icccm4
