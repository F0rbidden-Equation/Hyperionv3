### HyperionV3 Compatibility : Mint,Ubuntu (Debian take version kali linux)
![readme13](https://user-images.githubusercontent.com/59021489/106516732-c9201000-64d7-11eb-8b2c-0e402c3d64fb.jpg)

![readme-suite3](https://user-images.githubusercontent.com/59021489/106468501-4c247480-649e-11eb-8919-f24069a02c8c.jpg)
